class Utils() :
    BASE_URL = "https://dodamapi.b1nd.com"
    TOKEN_TYPE = "Bearer"